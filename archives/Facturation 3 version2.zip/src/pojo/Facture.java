package pojo;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;


public class Facture implements Serializable {
  private int idFacture;

  private Client client = null;

  private Set<Vendeur> vendeur = null;

  private Set<Lot> lots = new HashSet<Lot>(0);

  private String nrFacture;

  private Date dateFacturation;

  private char modePaiement;

  private boolean payer;

  private char typeAchat;

  public double montantTotalTvac() {
	  return 0.0;
  }

  private double tauxTva;

}
