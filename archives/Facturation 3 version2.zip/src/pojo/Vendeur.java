package pojo;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "vendeur", catalog = "facturation3")
@AttributeOverrides({ 
	@AttributeOverride(name="nom", column=@Column(name="nom")),
	@AttributeOverride(name="prenom", column=@Column(name="prenom")), 
	@AttributeOverride(name="email", column=@Column(name="email")), 
	@AttributeOverride(name="telephone", column=@Column(name="telephone")) })
public class Vendeur extends Personne implements Serializable {
	// private Set<Facture> factures = new HashSet<Facture>(0);
	
	@Override
	public String toString() {
		return "Vendeur [id=" + id + ", nom=" + nom + ", prenom=" + prenom
				+ ", email=" + email + ", telephone=" + telephone + "]";
	}
  
	
	

}
