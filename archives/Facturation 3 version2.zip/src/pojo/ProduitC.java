package pojo;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "produit", catalog = "facturation3")
@DiscriminatorValue("ProduitC")
public class ProduitC extends Produit implements Serializable {
	public ProduitC(){
		
	}
	
	
  private Set<Composite> composites = new HashSet<Composite>(0);

  @ManyToMany(fetch = FetchType.LAZY)
  @JoinTable(name="detailComposite", catalog="",  joinColumns = {  
		  @JoinColumn(name="produit_idProduit", nullable=false, updatable=false) }, inverseJoinColumns = {  
		  @JoinColumn(name="composite_idComposite", nullable=false, updatable=false) }) 
	public Set<Composite> getComposites() {
		return composites;
	}
	
	public void setComposites(Set<Composite> composites) {
		this.composites = composites;
	}

public double retourPrix() {
	  return 0.0;
  }

}
