package pojo;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;


public class Lot implements Serializable {
  private int idLot;

  private int quantite;

  private Produit produit = null;

  private Set<Facture> factures = new HashSet<Facture>(0);

}
