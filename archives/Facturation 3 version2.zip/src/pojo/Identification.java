package pojo;

import java.io.Serializable;


public class Identification implements Serializable {
  private String login;

  private String password;

  private Client client = null;

}
